from flask import Flask, render_template, request, redirect, url_for
import os
import hashlib

app = Flask(__name__)
URLS_FILE = "urls.txt"


def load_urls():
    """Read all saved short->long urls from text file into a dict."""
    urls = {}
    if os.path.exists(URLS_FILE):
        with open(URLS_FILE, "r") as f:
            for line in f:
                short, long = line.strip().split(" ", 1)
                urls[short] = long
    return urls


def save_url(short, long):
    """Append a new short->long url to text file."""
    with open(URLS_FILE, "a") as f:
        f.write(f"{short} {long}\n")


@app.route("/", methods=["GET", "POST"])
def index():
    short_url = None
    if request.method == "POST":
        original_url = request.form["url"].strip()
        # generate short hash
        short = hashlib.md5(original_url.encode()).hexdigest()[:6]
        urls = load_urls()

        if short not in urls:  # save only if not already stored
            save_url(short, original_url)

        short_url = request.host_url + short

    return render_template("index.html", short_url=short_url)


@app.route("/<short>")
def redirect_to_url(short):
    urls = load_urls()
    if short in urls:
        return redirect(urls[short])
    return "URL not found", 404


if __name__ == "__main__":
    app.run(debug=True)
